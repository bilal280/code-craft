import { PortfolioItemType, CategoryType } from '../types';

export const categories: CategoryType[] = [
  { id: "all", name: "الكل" },
  { id: "web", name: "مواقع إلكترونية" },
  { id: "app", name: "تطبيقات" },
  { id: "ui", name: "واجهات مستخدم" }
];

export const portfolioItems: PortfolioItemType[] = [
  {
    id: 1,
    title: "منصة تعليمية",
    category: "web",
    image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "منصة تعليمية متكاملة مع نظام إدارة محتوى وفصول افتراضية"
  },
  {
    id: 2,
    title: "تطبيق إدارة المهام",
    category: "app",
    image: "https://images.unsplash.com/photo-1555421689-491a97ff2040?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "تطبيق لإدارة المهام والمشاريع مع خصائص متقدمة للتنظيم"
  },
  {
    id: 3,
    title: "موقع للتجارة الإلكترونية",
    category: "web",
    image: "https://images.unsplash.com/photo-1557821552-17105176677c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "متجر إلكتروني متكامل مع نظام دفع آمن وإدارة المخزون"
  },
  {
    id: 4,
    title: "تصميم تطبيق صحي",
    category: "ui",
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "واجهة مستخدم لتطبيق متابعة الصحة واللياقة البدنية"
  },
  {
    id: 5,
    title: "تطبيق توصيل طعام",
    category: "app",
    image: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "تطبيق لطلب وتوصيل الطعام مع تتبع مباشر للطلبات"
  },
  {
    id: 6,
    title: "تصميم موقع شركة",
    category: "ui",
    image: "https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
    description: "واجهة مستخدم لموقع شركة احترافي بتصميم عصري"
  }
];
